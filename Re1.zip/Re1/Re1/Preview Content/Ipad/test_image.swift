//
//  test_image.swift
//  Re1
//
//  Created by 장하다 on 2023/12/01.
//

import SwiftUI
import MobileCoreServices // UIImagePickerController에서 사용되는 상수들을 포함합니다.

struct test_image: View {
    @State private var showImagePicker = false
    @State private var selectedImageURL: URL?

    var body: some View {
        VStack {
            Button("Select Image") {
                self.showImagePicker.toggle()
            }
            .sheet(isPresented: $showImagePicker) {
                ImagePicker(selectedImageURL: self.$selectedImageURL)
            }

            if let imageURL = selectedImageURL {
                Image(uiImage: UIImage(contentsOfFile: imageURL.path) ?? UIImage())
                    .resizable()
                    .frame(width: 500, height: 500)
            }
        }
    }
}

struct ImagePicker: UIViewControllerRepresentable {
    @Binding var selectedImageURL: URL?

    func makeUIViewController(context: Context) -> UIImagePickerController {
        let imagePicker = UIImagePickerController()
        imagePicker.delegate = context.coordinator
        imagePicker.sourceType = .photoLibrary
        //imagePicker.mediaTypes = [kUTTypeImage as String]
        return imagePicker
    }

    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {}

    func makeCoordinator() -> Coordinator {
        Coordinator(parent: self)
    }

    class Coordinator: NSObject, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
        let parent: ImagePicker

        init(parent: ImagePicker) {
            self.parent = parent
        }

        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
            if let imageURL = info[.imageURL] as? URL {
                parent.selectedImageURL = imageURL
            }
            picker.dismiss(animated: true)
        }
    }
}
