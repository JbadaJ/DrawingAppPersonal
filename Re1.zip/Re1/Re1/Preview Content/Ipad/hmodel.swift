//
//  hmodel.swift
//  Re1
//
//  Created by 장하다 on 2023/10/26.
//

import Foundation
import SwiftUI

struct hmodel: Hashable {
    let num: Int
    let desc: String
    let button: String
    let img: String
    let color:Color
}

extension hmodel {
    static let list: [hmodel] = [
        hmodel(num: 0, desc: "원하시는 헤어스타일이 있으신가요?", button: "시뮬레이션", img: "illust01",color:Color(red: 152/255, green: 174/255, blue: 242/255)),
    hmodel(num: 1,desc: "이전 스타일을 이어서 하시고 싶나요?", button: "불러오기", img: "illust02",color: Color(red: 167/255, green: 152/255, blue: 247/255)),
    hmodel(num: 2,desc: "잘 모르시겠나요? ", button: "스타일 추천", img: "illust03",color: Color(red: 206/255, green: 170/255, blue: 250/255))
    ]
}


