//
//  home.swift
//  Re1
//
//  Created by 장하다 on 2023/11/16.
//

import SwiftUI

struct home: View {
    @State private var showSheet = false
    @State private var showprofile = false
    
    init() {
        // Navigation Bar 설정 font size 조절위해 사용
        let appearance = UINavigationBarAppearance()
        appearance.titleTextAttributes = [.font: UIFont.systemFont(ofSize: 30)]
        UINavigationBar.appearance().standardAppearance = appearance
        UINavigationBar.appearance().scrollEdgeAppearance = appearance
    }
    
    var body: some View{
        GeometryReader { geometry in
            
            VStack(spacing: 30){
                
                Text("안녕하세요! Guest 님")
                    .frame(width:geometry.size.width*0.8,height: geometry.size.height*0.02)
                    .lineLimit(1)
                    .multilineTextAlignment(.leading)
                    .background(Color.white)
                    .foregroundColor(Color.black)
                    .padding(.top,geometry.size.height*0.2)
                
                HStack{
                    VStack(alignment: .leading, spacing: 5){
                        Text("원하시는 헤어스타일이 있으신가요?")
                            .lineLimit(1)
                            .frame(width: geometry.size.width*0.5, height: geometry.size.height*0.015)
                                .font(Font.system(size: 23))
                                .padding(.top , 2)
                                .padding(.bottom, 20)
                                .fontWeight(.black)
                        
                        Button(action: {
                            showSheet.toggle()
                        }){
                            Text("시뮬레이션")
                                .frame(width: geometry.size.width*0.25, height: geometry.size.height*0.05)
                                .foregroundColor(Color(red: 87/255, green: 79/255, blue: 187/255))
                                .font(Font.system(size: 20).bold())
                                .background(Color.white)
                                .cornerRadius(30)
                                .fontWeight(.heavy)
                                .padding(.leading,geometry.size.width*0.04)
                        }.fullScreenCover(isPresented: $showSheet, content: {
                            ContentView(showSheet: $showSheet) })
                    }.padding(.leading,geometry.size.width*0.08)
                    Spacer()
                    Image("illust01")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .padding(.trailing,geometry.size.width*0.08)
                }
                .frame(width: geometry.size.width*0.88, height: 150)
                .background(Color(red: 152/255, green: 174/255, blue: 242/255))
                .cornerRadius(30)

                HStack{
                    VStack(alignment: .leading, spacing: 5){
                        Text("이전 스타일을 이어서 하시고 싶나요?")
                            .lineLimit(1)
                            .frame(width: geometry.size.width*0.5, height: geometry.size.height*0.015)
                                .font(Font.system(size: 23))
                                .padding(.top , 2)
                                .padding(.bottom, 20)
                                .fontWeight(.black)
                        
                        Button{
                            print("button tapped")
                        }label: {
                            Text("불러오기")
                                .frame(width: geometry.size.width*0.25, height: geometry.size.height*0.05)
                                .foregroundColor(Color(red: 87/255, green: 79/255, blue: 187/255))
                                .font(Font.system(size: 20).bold())
                                .background(Color.white)
                                .cornerRadius(30)
                                .fontWeight(.heavy)
                                .padding(.leading,geometry.size.width*0.04)                        }
                    }.padding(.leading,geometry.size.width*0.08)
                    Spacer()
                    Image("illust02")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .padding(.trailing,geometry.size.width*0.08)
                }
                .frame(width: geometry.size.width*0.88, height: 150)
                .background(Color(red: 167/255, green: 152/255, blue: 247/255))
                .cornerRadius(30)
                
                HStack {
                    VStack(spacing: 5) {
                        Text("잘 모르시겠나요?")
                            .lineLimit(1)
                            .frame(width: geometry.size.width*0.46, height: geometry.size.height*0.015)
                                .font(Font.system(size: 23))
                                .padding(.top , 2)
                                .padding(.bottom, 20)
                                .fontWeight(.black)
                        //고칠것: 임시로 naver로 주소 설정함 추가적으로 url설정 필요
                        Link(destination: URL(string: "https://www.naver.com")!, label: {
                            Text("스타일 추천")
                                .frame(width: geometry.size.width*0.25, height: geometry.size.height*0.05)
                                .foregroundColor(Color(red: 87/255, green: 79/255, blue: 187/255))
                                .font(Font.system(size: 20).bold())
                                .background(Color.white)
                                .cornerRadius(30)
                                .fontWeight(.heavy)
                                .padding(.leading,geometry.size.width*0.04)
                        })
                    }
                             
                    Spacer()
                    Image("illust03")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .padding(.trailing,geometry.size.width*0.08)
                }
                .frame(width: geometry.size.width*0.88, height: 150)
                .background(Color(red: 206/255, green: 170/255, blue: 250/255))
                .cornerRadius(30)
                Spacer()
           }
            .frame(maxWidth: geometry.size.width * 0.8, maxHeight: geometry.size.height)
                .background(Color.white)
                .padding(.horizontal,geometry.size.width*0.1)
        }
    }
}

struct home_Previews: PreviewProvider {
    static var previews: some View {
        home()
    }
}
