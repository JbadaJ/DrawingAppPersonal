//home 과 navigationBar bottombar 합친 최종본
import SwiftUI


struct home_view: View{
    init() {
        // Navigation Bar 설정 font size 조절위해 사용
        let appearance = UINavigationBarAppearance()
        appearance.titleTextAttributes = [.font: UIFont.systemFont(ofSize: 25)]
        UINavigationBar.appearance().standardAppearance = appearance
        UINavigationBar.appearance().scrollEdgeAppearance = appearance
    }
    var body: some View{
        GeometryReader{ geometry in
            
            NavigationView{
                HStack{
                    bottombar()
                        .navigationBarTitle("Hair Sketcher",displayMode: .inline)
                        .font(Font.system(size: 25))
                        .toolbar {
                            ToolbarItem(placement: .navigationBarTrailing) {
                                NavigationLink(destination: alarm_view()) {
                                    Image(systemName: "bell")
                                        .resizable()
                                        .frame(width: geometry.size.width*0.05,height: geometry.size.height*0.035)
                                        .foregroundColor(Color.gray)
                                        .padding(geometry.size.width*0.01)
                                }
                            }
                            ToolbarItem(placement: .navigationBarTrailing) {
                                NavigationLink(destination: app_info()) {
                                    Image(systemName: "info.circle")
                                        .resizable()
                                        .frame(width: geometry.size.width*0.05,height: geometry.size.height*0.035)
                                        .foregroundColor(Color.gray)
                                        .padding(geometry.size.width*0.01)
                                }
                            }
                        }
                }.background(Color.white)
            }.navigationViewStyle(StackNavigationViewStyle())
        }
    }
}





struct home_view_Previews: PreviewProvider {
    static var previews: some View {
        home_view()
    }
}

