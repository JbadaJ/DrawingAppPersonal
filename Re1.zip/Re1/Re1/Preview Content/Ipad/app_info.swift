//
//  app_info.swift
//  Re1
//
//  Created by 장하다 on 2023/11/17.
//

import SwiftUI

struct app_info: View {
    var body: some View {
        GeometryReader{geometry in
            NavigationView{
                Text("Hair Sketcher Information")
            }.navigationViewStyle(StackNavigationViewStyle())
        }
    }
}

struct app_info_Previews: PreviewProvider {
    static var previews: some View {
        app_info()
    }
}
