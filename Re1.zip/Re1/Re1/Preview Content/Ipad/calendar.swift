//
//  calendar.swift
//  Re1
//
//  Created by 장하다 on 2023/10/31.
//

import SwiftUI

struct calendar: View {
    
    @State private var date = Date()

    var body: some View {
        DatePicker(
            "Start Date",
            selection: $date,
            displayedComponents: [.date]
        )
        .datePickerStyle(.graphical)
    }
}


struct calendar_Previews: PreviewProvider {
    static var previews: some View {
        calendar()
    }
}
