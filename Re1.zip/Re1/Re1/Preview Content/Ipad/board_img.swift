import SwiftUI

struct board_img: View {
    let items = board_img_info.Image_list
    var body: some View {
        GeometryReader { geometry in
                
                ScrollView {
                    NavigationLink(destination: board_make()) {
                                    Text("New")
                                        .padding()
                                        .background(Color.blue)
                                        .foregroundColor(.white)
                                        .cornerRadius(8)
                                }
                    ForEach(items, id: \.self) { item in
                        VStack {
                            HStack{
                                Text(item.title).font(.title)
                                Text(item.date)
                            }
                            Image(item.img)
                                .resizable()
                                .background(Color.white)
                                .cornerRadius(20)
                                .frame(width: geometry.size.width * 0.6, height: geometry.size.height * 0.3)
                            
                            Text(item.desc)
                                .font(.headline)
                            
                            Divider()
                        }
                        .frame(width: geometry.size.width * 0.8, height: geometry.size.height * 0.3)
                        .padding(.vertical, geometry.size.height * 0.05)
                        .padding(.horizontal, geometry.size.width * 0.1)
                    }
                
            }
            .navigationViewStyle(StackNavigationViewStyle())
        }
    }
}

struct board_img_Previews: PreviewProvider {
    static var previews: some View {
        board_img()
    }
}
