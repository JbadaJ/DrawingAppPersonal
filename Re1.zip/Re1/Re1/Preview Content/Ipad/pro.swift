//
//  pro.swift
//  Re1
//
//  Created by 장하다 on 2023/10/29.
//

import SwiftUI

struct pro: View {
    var body: some View{
        GeometryReader { geometry in
            Spacer()
            VStack(spacing: 40){
                VStack{
                    HStack{
                        Image("img_profile_empty_right")
                            .overlay(
                                Button(action: {
                                    // 버튼이 클릭되었을 때 실행할 코드
                                }) {
                                    Image("ic_edit")
                                        .resizable()
                                        .background(Color.purple)
                                        .frame(width: geometry.size.width*0.035, height: geometry.size.width*0.035)
                                        .cornerRadius(30)
                                }
                                    .offset(x: 0, y:0),
                                alignment: .topTrailing // 오른쪽 위에 버튼 위치
                            )
                        Image("img_profile_empty_front")
                            .overlay(
                                Button(action: {
                                    // 버튼이 클릭되었을 때 실행할 코드
                                }) {
                                    Image("ic_edit")
                                        .resizable()
                                        .background(Color.purple)
                                        .frame(width: geometry.size.width*0.035, height: geometry.size.width*0.035)
                                        .cornerRadius(30)
                                }
                                    .offset(x: 0, y:0),
                                alignment: .topTrailing // 오른쪽 위에 버튼 위치
                            )
                        
                        Image("img_profile_empty_left")
                            .overlay(
                                Button(action: {
                                    // 버튼이 클릭되었을 때 실행할 코드
                                }) {
                                    Image("ic_edit")
                                        .resizable()
                                        .background(Color.purple)
                                        .frame(width: geometry.size.width*0.035, height: geometry.size.width*0.035)
                                        .cornerRadius(30)
                                }
                                    .offset(x: 0, y:0),
                                alignment: .topTrailing // 오른쪽 위에 버튼 위치
                            )
                        
                    }
                    
                    VStack{
                        HStack(){
                            HStack{
                                Text("기장")
                                    .padding(.trailing, geometry.size.width*0.05)
                                    .padding(.leading,geometry.size.width*0.15)
                                Image("ic_edit")
                                    .resizable()
                                    .background(Color.gray)
                                    .frame(width: geometry.size.width*0.035, height: geometry.size.width*0.035)
                                    .cornerRadius(30)
                            }
                            Spacer()
                            HStack{
                                Text("색상")
                                    .padding(.trailing, geometry.size.width*0.05)
                                Image("ic_edit")
                                    .resizable()
                                    .background(Color.gray)
                                    .frame(width: 30, height: 30)
                                    .cornerRadius(30)
                                    .padding(.trailing, geometry.size.width*0.15)
                            }
                            
                        }
                        
                        HStack{
                            HStack{
                                Text("커트 스타일")
                                    .padding(.trailing, geometry.size.width*0.05)
                                    .padding(.leading,geometry.size.width*0.15)
                                Image("ic_edit")
                                    .resizable()
                                    .background(Color.gray)
                                    .frame(width: geometry.size.width*0.035, height: geometry.size.width*0.035)
                                    .cornerRadius(30)
                            }
                            Spacer()
                            HStack{
                                Text("펌")
                                    .padding(.trailing, geometry.size.width*0.05)
                                Image("ic_edit")
                                    .resizable()
                                    .background(Color.gray)
                                    .frame(width: 30, height: 30)
                                    .cornerRadius(30)
                                    .padding(.trailing, geometry.size.width*0.15)
                            }
                        }
                        
                        HStack{
                            HStack{
                                Text("추가 참고사항")
                                    .padding(.trailing, geometry.size.width*0.05)
                                    .padding(.leading,geometry.size.width*0.15)
                                Image("ic_edit")
                                    .resizable()
                                    .background(Color.gray)
                                    .frame(width: geometry.size.width*0.035, height: geometry.size.width*0.035)
                                    .cornerRadius(30)
                                Spacer()
                            }
                        }
                        HStack{
                            Spacer()
                            Button(action: {
                                // save
                            }) {
                                Image(systemName: "square.and.arrow.up.circle")
                                    .resizable()
                                    .frame(width: geometry.size.width*0.06, height: geometry.size.height*0.04)
                            }
                        }
                    }
                }
                .frame(width: geometry.size.width*0.8)
                .padding()
                .background(Color.white)
                .cornerRadius(10)
                .shadow(color: Color.black.opacity(0.1), radius: 10, x: 0, y: 5)
                
                VStack(spacing: 20){
                    HStack{
                        Text("추천 미용실")
                            .font(Font.system(size: 20).bold())
                            .padding(.leading , geometry.size.width*0.06)
                        Spacer()
                        
                        Link(destination: URL(string: "https://www.naver.com")!, label:{
                            Image(systemName: "location.square.fill")
                                .resizable()
                                .frame(width: geometry.size.width*0.045, height: geometry.size.height*0.033)
                        }).padding(.trailing, 40)
                        
                        
                        Button(action: {
                            print("Button clicked!")
                        }) {
                            Text("정보")
                                .frame(width: geometry.size.width*0.06, height: geometry.size.height*0.01)
                                .foregroundColor(Color.black)
                                .padding()
                                .background(Color.white)
                                .cornerRadius(10)
                                .shadow(color: Color.black.opacity(0.1), radius: 10, x: 0, y: 5)
                        }
                        .padding(.trailing, 50)
                    }
                    
                    HStack{
                        VStack{
                            Image("min")
                                .resizable()
                                .frame(width: geometry.size.width*0.12, height: geometry.size.width*0.13)
                                .aspectRatio(contentMode: .fit)
                            
                            Text("민스 뷰티")
                        }.padding(.trailing,40)
                        
                        VStack{
                            Image("ma")
                                .resizable()
                                .frame(width: geometry.size.width*0.12, height: geometry.size.width*0.13)
                                .aspectRatio(contentMode: .fit)
                            
                            Text("마실 헤어")
                        }.padding(.trailing,40)
                        
                        VStack{
                            Image("snob")
                                .resizable()
                                .frame(width: geometry.size.width*0.12, height: geometry.size.width*0.13)
                                .aspectRatio(contentMode: .fit)
                            
                            Text("snob")
                        }.padding(.trailing,50)
                        
                        VStack{
                            Image("shal")
                                .resizable()
                                .frame(width: geometry.size.width*0.12, height: geometry.size.width*0.13)
                                .aspectRatio(contentMode: .fit)
                            
                            Text("살롱 드 뮤즈")
                        }
                    }.padding(.top, 10)
                }
                .frame(width: geometry.size.width*0.8)
                .padding()
                .background(Color.white)
                .cornerRadius(10)
                .shadow(color: Color.black.opacity(0.1), radius: 10, x: 0, y: 5)
                
                HStack{
                    Button(action: {
                        print("Button clicked!")
                    }) {
                        Text("예약")
                            .font(Font.system(size: 30).italic())
                        .frame(width: geometry.size.width*0.2, height: geometry.size.width*0.07)
                            .foregroundColor(Color.black)
                            .padding()
                            .background(Color.white)
                            .cornerRadius(10)
                            .shadow(color: Color.black.opacity(0.1), radius: 10, x: 0, y: 5)
                    }
                }.background(Color.white)
                
            }.background(Color.white)
                .foregroundColor(Color.black)
                .padding(.horizontal, geometry.size.width*0.08)
                .padding(.top,geometry.size.height*0.1)
            
        }.background(Color.white)
    }
}






struct pro_Previews: PreviewProvider {
    static var previews: some View {
        pro()
    }
}
