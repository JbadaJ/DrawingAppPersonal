//
//  alarm_view.swift
//  Re1
//
//  Created by 장하다 on 2023/11/17.
//

import SwiftUI

struct alarm_view: View {
    var body: some View {
        GeometryReader{geometry in
            NavigationView{
                Text("새로운 알림이 없습니다.")
            }.navigationViewStyle(StackNavigationViewStyle())
        }
    }
}

struct alarm_view_Previews: PreviewProvider {
    static var previews: some View {
        alarm_view()
    }
}
