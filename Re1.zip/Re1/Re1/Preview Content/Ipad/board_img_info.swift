//
//  board_img_info.swift
//  Re1
//
//  Created by 장하다 on 2023/12/01.
//

import Foundation
import SwiftUI

struct board_img_info: Hashable {
    let num: Int
    let desc: String
    let button: String
    let img: String
    let date:String
    let title:String
}

extension board_img_info {
    static let Image_list: [board_img_info] = [
        board_img_info(num: 0, desc: "milky way and space", button: "botton", img: "milky_space",date: "11/17",title: "Night Trip"),
        board_img_info(num: 1, desc: "beach with sunshine", button: "botton", img: "beach_sun",date: "07/12",title: "Ocean"),
        board_img_info(num: 2, desc: "butterfly eat flower", button: "botton", img: "flower_butter",date: "09/20",title: "Forest")
        
    ]
}
