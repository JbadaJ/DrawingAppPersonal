//
//  page.swift
//  Re1
//
//  Created by 장하다 on 2023/10/29.
import SwiftUI
import PencilKit

struct Page: UIViewRepresentable {
    @Binding var canvasView: PKCanvasView
    let toolPicker = PKToolPicker()

    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    func makeUIView(context: Context) -> PKCanvasView {
        canvasView.tool = PKInkingTool(.pen, color: UIColor.black, width: 5)
        canvasView.drawingPolicy = .anyInput
        canvasView.becomeFirstResponder()
        canvasView.backgroundColor = UIColor.white


        toolPicker.setVisible(true, forFirstResponder: canvasView)
        toolPicker.addObserver(canvasView)

        return canvasView
    }

    func updateUIView(_ uiView: PKCanvasView, context: Context) {
    }

    class Coordinator: NSObject {
        var parent: Page

        init(_ parent: Page) {
            self.parent = parent
        }
    }
}

struct ContentView: View {
    
    @State private var canvasView = PKCanvasView()
    
    @Binding var showSheet:Bool
    
    var body: some View {
        VStack {
            Page(canvasView: $canvasView)
                .frame(maxWidth: .infinity, maxHeight: .infinity)

            HStack{
                
                Button("Clear Drawing") {
                    canvasView.drawing = PKDrawing()
                }.frame(width: 150, height: 50)
                    .background(Color.cyan)
                    .cornerRadius(30)
                    .foregroundColor(Color.black)
                Button("back"){
                    showSheet.toggle()
                }.frame(width: 150, height: 50)
                    .background(Color.cyan)
                    .cornerRadius(30)
                    .foregroundColor(Color.black)
            }
        }
    }
}


