//
//  bottombar.swift
//  Re1
//
//  Created by 장하다 on 2023/10/30.
//
import SwiftUI

struct bottombar: View {
    var body: some View {
        GeometryReader { geometry in
            TabView{
                home()
                    .tabItem{
                        Image("home")
                        Text("홈")
                        
                    }
                pro()
                    .tabItem{
                        Image("profile")
                        Text("프로필")
                    }
                developing().tabItem{
                    Image(systemName: "exclamationmark.square.fill").resizable()
                    Text("미구현 기능")
                }
            }.onAppear {
                if #available(iOS 15.0, *) {
                    let appearance = UITabBarAppearance()
                    UITabBar.appearance().scrollEdgeAppearance = appearance
                }
                }
        }
    }
}

struct bottombar_Previews: PreviewProvider {
    static var previews: some View {
        bottombar()
    }
}
