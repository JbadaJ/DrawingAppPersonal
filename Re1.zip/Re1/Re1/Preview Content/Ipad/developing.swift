//
//  developing.swift
//  Re1
//
//  Created by 장하다 on 2023/11/17.
//

import SwiftUI

struct developing: View {
    var body: some View {
        GeometryReader{geometry in
            NavigationView {
                VStack (spacing:30){
                    NavigationLink(destination: login_view()) {
                        Text("login 기능")
                    }
                    NavigationLink(destination: calendar()) {
                        Text("달력 기능")
                    }
                    NavigationLink(destination: board_img()) {
                        Text("게시판 이미지")
                    }
                    NavigationLink(destination: test_image()) {
                        Text("이미지 가져오기")
                    }


                }
            }.navigationViewStyle(StackNavigationViewStyle())
        }
    }
}

struct developing_Previews: PreviewProvider {
    static var previews: some View {
        developing()
    }
}
