import SwiftUI

struct board_make: View {
    @State private var title: String = ""
    @State private var date = Date()
    @State private var desc: String = ""
    @Environment(\.presentationMode) var end
    var body: some View {
        GeometryReader { geometry in
            VStack {
                ForEach(0..<3) { i in
                    switch i {
                        case 0:
                            TextField("Enter Title", text: $title)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                                .padding()
                        case 1:
                        TextField("Enter Description", text: $desc)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .padding()
                        case 2:
                        DatePicker("Select a date", selection: $date, displayedComponents: .date)
                                        .datePickerStyle(.compact)
                                        .padding()
                        default:
                            Text("Error")
                    }
                }//for
                Button(action: {
                                        // 이전 페이지로 돌아가기
                                        end.wrappedValue.dismiss()
                                    }) {
                                        Text("SAVE")
                                            .padding()
                                            .background(Color.cyan)
                                            .foregroundColor(.white)
                                            .cornerRadius(8)
                                    }
            }//vstack

        }//geo
    }//body
}

struct board_make_Previews: PreviewProvider {
    static var previews: some View {
        board_make()
    }
}
