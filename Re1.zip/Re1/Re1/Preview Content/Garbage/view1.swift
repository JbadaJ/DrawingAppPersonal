//
//  view1.swift
//  Re1
//
//  Created by 장하다 on 2023/10/26.
//
// 초기버전 참고용 삭제가능
import SwiftUI


struct view1: View{
    //@Binding var showContentView: Bool
    @State private var showSheet = false
    @State private var showprofile = false
    
    var body: some View{
        GeometryReader { geometry in
            VStack(spacing: 30){

                Spacer()
                Text("안녕하세요! Guest 님")
                    .frame(width: 400)
                    .lineLimit(1)
                    .padding(.trailing,500)
                    .foregroundColor(Color.black) 
                
                HStack{
                    VStack(alignment: .leading, spacing: 5){
                        Text("원하시는 헤어스타일이 있으신가요?")
                            .lineLimit(1)
                                .frame(width: 350, height: 10)
                                .font(Font.system(size: 23))
                                .padding(.top , 2)
                                .padding(.bottom, 20)
                                .fontWeight(.black)
                        
                        Button(action: {
                            showSheet.toggle()
                        }){
                            Text("시뮬레이션")
                                .frame(width: 100, height: 50)
                                .foregroundColor(Color(red: 87/255, green: 79/255, blue: 187/255))
                                .font(Font.system(size: 20).bold())
                                .background(Color.white)
                                .cornerRadius(30)
                                .fontWeight(.heavy)
                        }.fullScreenCover(isPresented: $showSheet, content: {
                            ContentView(showSheet: $showSheet) })
                        
                    }.padding(.trailing,150)
                        .frame(alignment: .trailing)

                    Image("illust01")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                }
                .frame(width: 700, height: 150)
                .background(Color(red: 152/255, green: 174/255, blue: 242/255))
                .cornerRadius(30)

                HStack{
                    VStack(alignment: .leading, spacing: 5){
                        Text("이전 스타일을 이어서 하시고 싶나요?")
                            .lineLimit(1)
                                .frame(width: 350, height: 10)
                                .font(Font.system(size: 23))
                                .padding(.top , 2)
                                .padding(.bottom, 20)
                                .fontWeight(.black)
                        
                        Button{
                            print("button tapped")
                        }label: {
                            Text("불러오기")
                                .frame(width: 100, height: 50)
                                .foregroundColor(Color(red: 87/255, green: 79/255, blue: 187/255))
                                .font(Font.system(size: 20))
                                .fontWeight(.heavy)
                                .background(Color.white)
                                .cornerRadius(30)
                        }
                    }.padding(.trailing,150)
                        .frame(alignment: .trailing)

                    Image("illust02")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                }
                .frame(width: 700, height: 150)
                .background(Color(red: 167/255, green: 152/255, blue: 247/255))
                .cornerRadius(30)
                
                HStack {
                    VStack(spacing: 5) {
                        Text("잘 모르시겠나요?")
                            .lineLimit(1)
                            .font(Font.system(size: 23))
                            .padding(.top, 2)
                            .padding(.bottom, 20)
                            .fontWeight(.black)
                        
                        Button(action: {
                            print("button tapped")
                        }) {
                            Text("맞춤 스타일 추천")
                                .lineLimit(1)
                                .frame(width: 150, height: 50)
                                .font(Font.system(size: 20))
                                .fontWeight(.heavy)
                                .background(Color.white)
                                .foregroundColor(Color(red: 87/255, green: 79/255, blue: 187/255))
                                .cornerRadius(30)
                        }
                    }
                    .padding(.leading,55)
                    
                    Spacer()
                    Image("illust03")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .padding(.trailing,60)
                }
                .frame(width: 700, height: 150)
                .background(Color(red: 206/255, green: 170/255, blue: 250/255))
                .cornerRadius(30)
                Spacer()
           }
            .frame(maxWidth: geometry.size.width * 0.8, maxHeight: geometry.size.height)
                .padding(.horizontal, geometry.size.width/10)
                .background(Color.white)
        }
    }
}



