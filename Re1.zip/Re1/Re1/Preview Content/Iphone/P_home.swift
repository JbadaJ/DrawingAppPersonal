//
//  P_home.swift
//  Re1
//
//  Created by 장하다 on 2023/11/21.
//

import SwiftUI

struct P_home: View {
    //@State private var showSheet = false
    @State private var showprofile = false
    
    init(){
        let appearance = UINavigationBarAppearance()
        appearance.configureWithDefaultBackground()
        UINavigationBar.appearance().scrollEdgeAppearance = appearance
    }
    var body: some View {
        NavigationView{
            GeometryReader { geometry in
                title_h_1().navigationBarTitle("Hair sketcher", displayMode: .inline)
                P_Bottom()
            }
        }//nav
        
    }//body
}
struct P_home_Previews: PreviewProvider {
    static var previews: some View {
        P_home()
    }
}
