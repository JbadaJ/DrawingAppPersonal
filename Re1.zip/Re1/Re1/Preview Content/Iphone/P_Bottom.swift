//
//  P_Bottom.swift
//  Re1
//
//  Created by 장하다 on 2023/11/21.
//

import SwiftUI

struct P_Bottom: View {
    var body: some View {
        GeometryReader { geometry in
            TabView{
                title_h_1()
                    .tabItem{
                        Image("home")
                        Text("홈")
                    }
                P_pro()
                    .tabItem{
                        Image("profile")
                        Text("프로필")
                    }
                developing().tabItem{
                    Image(systemName: "exclamationmark.square.fill").resizable()
                    Text("미구현 기능")
                }
            }.onAppear {
                if #available(iOS 15.0, *) {
                    let appearance = UITabBarAppearance()
                    UITabBar.appearance().scrollEdgeAppearance = appearance
                }
                }
        }
    }
}

struct P_Bottom_Previews: PreviewProvider {
    static var previews: some View {
        P_Bottom()
    }
}
