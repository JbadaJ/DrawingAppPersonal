//
//  title_h_1.swift
//  Re1
//
//  Created by 장하다 on 2023/11/21.
//

import SwiftUI

struct title_h_1: View {

    @State private var showSheet = false
    let items = hmodel.list

    
    var body: some View {
        
        
            GeometryReader { geometry in
                NavigationView{
                    
                    List(items, id: \.self) { item in
                        
                    HStack{
                        VStack(alignment: .leading, spacing: 5){
                            Text(item.desc)
                                .lineLimit(2)
                                .frame(width: geometry.size.width*0.4, height: geometry.size.height*0.07)
                                .font(Font.system(size: geometry.size.width*0.045))
                                    .fontWeight(.black)
                           
                            NavigationLink(
                                                            destination: move(item),
                                                            label: {
                                                                Text(item.button)
                                                                    .frame(width: geometry.size.width * 0.25, height: geometry.size.height * 0.05)
                                                                    .foregroundColor(Color(red: 87/255, green: 79/255, blue: 187/255))
                                                                    .font(Font.system(size: geometry.size.width * 0.045).bold())
                                                                    .background(Color.white)
                                                                    .cornerRadius(30)
                                                                    .fontWeight(.heavy)
                                                                    .padding(.leading, geometry.size.width * 0.04)
                                                            }
                                                        )
                            
                        }.padding(.leading,geometry.size.width*0.08)
                        Image(item.img)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .padding(.trailing,geometry.size.width*0.07)
                    }
                    .listRowBackground(Color.clear)
                    .frame(width: geometry.size.width*0.88, height: 150)
                    .background(item.color)
                    .cornerRadius(30)
                    .listRowSeparator(.hidden)
                    }.listStyle(.plain)
                    //list
                }//nav
        }//geo
    }//body
}//view

struct title_h_1_Previews: PreviewProvider {
    static var previews: some View {
        title_h_1()
    }
}

func move(_ item: hmodel)-> some View{
    if item.num == 0{
        return AnyView(P_content())
    }
    if item.num == 2{
        return AnyView(P_URL())
    }else{
        return AnyView(EmptyView())
    }
}
//Button(action: {
//    showSheet.toggle()
//}){
//    Text(item.button)
//        .frame(width: geometry.size.width*0.25, height: geometry.size.height*0.05)
//        .foregroundColor(Color(red: 87/255, green: 79/255, blue: 187/255))
//        .font(Font.system(size:geometry.size.width*0.045).bold())
//        .background(Color.white)
//        .cornerRadius(30)
//        .fontWeight(.heavy)
//        .padding(.leading,geometry.size.width*0.04)
//}.fullScreenCover(isPresented: $showSheet, content: {
//    ContentView(showSheet: $showSheet) })
