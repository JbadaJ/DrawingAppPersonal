//
//  P_Naver.swift
//  Re1
//
//  Created by 장하다 on 2023/11/21.
//

import Foundation
import SwiftUI

struct P_URL: View {
    var body: some View {
        VStack {
            LinkView(urlString: "https://www.naver.com", linkText: "Naver")
            LinkView(urlString: "https://www.google.com", linkText: "Google")
            LinkView(urlString: "https://www.youtube.com", linkText: "YouTube")
        }
    }
}

struct LinkView: View {
    let urlString: String
    let linkText: String
    
    var body: some View {
        Text(linkText)
            .padding(.top,10)
            .foregroundColor(.blue)
            .onTapGesture {
                if let url = URL(string: urlString) {
                    UIApplication.shared.open(url)
                }
            }
    }
}
