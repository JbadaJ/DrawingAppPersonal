//
//  Re1App.swift
//  Re1
//
//  Created by 장하다 on 2023/10/26.
//

import SwiftUI
import PencilKit

@main
struct Re1App: App {
    @State private var showSheet = false
    var body: some Scene {
        WindowGroup{
            if UIDevice.current.userInterfaceIdiom == .phone {
                       // 아이폰에서 작동
                       P_home()
                   } else if UIDevice.current.userInterfaceIdiom == .pad {
                       //아이패드에서 작동
                       home_view().preferredColorScheme(.light)
                       //light모드를 기본으로 설정
                   } else {
                       // 기타 디바이스? 비상용
                       Text("This is another device")
                   }
                
        }
    }
}
