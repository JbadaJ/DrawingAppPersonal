//
//  ViewController.swift
//  pencilkitTest1
//
//  Created by 장하다 on 2023/08/07.
//

import UIKit
import PencilKit

class ViewController: UIViewController , PKCanvasViewDelegate{

    @IBOutlet weak var canvasView: PKCanvasView!
    
    lazy var canvasWidth: CGFloat = canvasView.bounds.width
    lazy var canvasOverscrollHight: CGFloat = canvasView.bounds.height
    var drawing = PKDrawing()
    let toolPicker = PKToolPicker()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        canvasView.delegate = self
        canvasView.drawing = drawing
        
        canvasView.alwaysBounceVertical = true
        //이거 쓰면 그림그리기 활성화
        canvasView.drawingPolicy = .anyInput
    }
    //이거 하니까 tool나타남 ...냐ㅠㅕㅣ
    override func viewDidAppear(_ animated: Bool){
        //super.viewDidAppear(animated)
        //tool 상자 나타나라고 좀
        toolPicker.setVisible(true, forFirstResponder: canvasView)
        toolPicker.addObserver(canvasView)
        canvasView.becomeFirstResponder()
    }
    
}
//extension PKToolPickerObserver {
//    func toolPickerSelectedToolDidChange(_ toolPicker : PKToolPicker) {
//        print("바꼈어 바꼈다공러니러니ㅏ렁ㅌ")
//    }
//}

// 해야될것 거의다옴 왠지 모르겠는데 일단 색깔 도구 바뀜 진짜 이유모르겟음 일단 이건 보류고 도구가 바뀌는데 이거 어? 그럼 함수로체크할필요가 없는데 ?? 뭐지
//아무튼 위에 pktoolpkckerobserver 에서 func toolPickerSelectedToolDidChange(PKToolPicker) 를 이용해서 print로 체크해야함
//그래서 그 override or extention으로 함수 수정해서 해봐 이제 자러간다 ㅂㅂ


