//
//  canvasCell.swift
//  pencilkitTest1
//
//  Created by 장하다 on 2023/08/07.
//

import UIKit

class canvasCell: UICollectionViewCell {
    
}
