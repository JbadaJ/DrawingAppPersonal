//
//  SymbolRollerViewController.swift
//  Project_Symbol_Roler
//
//  Created by 장하다 on 2023/08/05.
//

import UIKit

class SymbolRollerViewController: UIViewController {
    
    //그림 불러서 배열에 저장
    let symbols: [String] = ["sun.min", "moon", "cloud", "wind", "snowflake"]
    
    
    @IBOutlet weak var imageView:UIImageView!
    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var button: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        reload()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    func reload(){
        let symbol = symbols.randomElement()!
        imageView.image = UIImage(systemName: symbol)
        label.text = symbol
    }
    
    @IBAction func buttonTapped(_ sender: Any) {
       reload()
        print("button tapped")
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
