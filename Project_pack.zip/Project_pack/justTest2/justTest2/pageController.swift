//
//  pageController.swift
//  justTest2
//
//  Created by 장하다 on 2023/08/09.
//
import PencilKit
import UIKit

class pageController: UIViewController {

    let canvasView: PKCanvasView = {
        let canvas = PKCanvasView()
        
        //컴퓨터에서 테스트때만 쓸것
        canvas.drawingPolicy = .anyInput
        return canvas
    }()
    

    @IBOutlet weak var buttons: UIStackView!
    //사진 가져오는 액션버튼
    @IBAction func tapPickup(){
        
        canvasView.isOpaque = true
        let vc = UIImagePickerController()
        vc.sourceType = .photoLibrary
        vc.delegate = self
        vc.allowsEditing = true
        present(vc, animated: true)

    }
    @IBAction func  reset() {
        print("update--")
        print("...")
    }
    
    var drawing = PKDrawing()
    let toolPicker = PKToolPicker()

    override func viewDidLoad() {
        super.viewDidLoad()
        canvasView.backgroundColor = UIColor.clear
        //canvasView.delegate = context.coordinator
        view.addSubview(canvasView)
    }
    
    override func viewDidAppear(_ animated: Bool){
        //super.viewDidAppear(animated)

        toolPicker.setVisible(true, forFirstResponder: canvasView)
        toolPicker.addObserver(canvasView)
        canvasView.becomeFirstResponder()
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        // 도구바 길이 설정
        let barH = view.frame.size.height / 15
        buttons.frame.size.height = barH
        
        canvasView.frame = CGRect(x: 0, y: barH, width: view.bounds.width, height: view.bounds.height - barH)
    }
}
//사진 가져오는것
extension pageController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
       
        if let image = info[UIImagePickerController.InfoKey(rawValue: "UIImagePickerControllerEditedImage")] as? UIImage {
            
            let toSend = UIImageView(image: image)
            toSend.contentMode = .scaleAspectFill
            toSend.clipsToBounds = true
            view.insertSubview(toSend, at: 1)
        }
        picker.dismiss(animated: true, completion: nil)
        
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
}
