//
//  pageCell.swift
//  justTest2
//
//  Created by 장하다 on 2023/08/09.
//

import UIKit

class pageCell: UICollectionViewCell {
    
}
