//
//  ContentView.swift
//  SwiftUiProject1
//
//  Created by 장하다 on 2023/08/20.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack{
            VStack{
                ImageView()
                ButtonView()
                TextView()
            }
            
            HStack{
                ImageView()
                ButtonView()
                TextView()
            }
            
            ZStack{
                ImageView()
                ButtonView()
                TextView()
                
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
