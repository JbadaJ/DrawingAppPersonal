//
//  SwiftUiProject1App.swift
//  SwiftUiProject1
//
//  Created by 장하다 on 2023/08/20.
//

import SwiftUI

@main
struct SwiftUiProject1App: App {
    var body: some Scene {
        WindowGroup {
            ButtonView()
        }
    }
}
