//
//  ButtonView.swift
//  SwiftUiProject1
//
//  Created by 장하다 on 2023/08/20.
//

import SwiftUI

struct ButtonView: View {
    var body: some View {
        Button {
            print("button clicked")
        } label: {
            Text("click me")
                .font(.system(size: 20, weight: .bold, design: .default))
                .foregroundColor(.white)
        }
        .padding()
        .frame(height: 100)
        .background(.pink)
        .cornerRadius(20)
        .opacity(1.2)
    }
}

struct ButtonView_Previews: PreviewProvider {
    static var previews: some View {
        ButtonView()
    }
}
