//
//  TextView.swift
//  SwiftUiProject1
//
//  Created by 장하다 on 2023/08/20.
//

import SwiftUI

struct TextView: View {
    var body: some View {
        Text("swift ui")
            .font(.system(size: 40, weight: .bold, design: .default))
    }
}

struct TextView_Previews: PreviewProvider {
    static var previews: some View {
        TextView()
    }
}
